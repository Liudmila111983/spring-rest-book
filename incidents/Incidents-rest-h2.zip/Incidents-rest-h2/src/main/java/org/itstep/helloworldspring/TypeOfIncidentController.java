package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // С помощью него выполняется обмен данными в формате json

public class TypeOfIncidentController {

    @Autowired
    TypeOfIncidentService typeOfIncidentService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping("/") // "/" подразумевает 8080
    public String index(){
        return "index";
    }

    @GetMapping(value="/type_of_incident")
    public List<TypeOfIncident> findAll(){
        return typeOfIncidentService.findAll();
    }

    /*
    @GetMapping(value="/users/{id}")
    public Optional<User> findById(@PathVariable Long id){
        return userService.findById(id);
    }

    @PostMapping(value="/users")
    public User post(@RequestBody User user){
        return userService.save(user);
    }

    @PutMapping(value="/users/{id}")
    public User update(@RequestBody User newUser, @PathVariable Long id){
        return userService.findById(id).map(user->{
            user.setUsername(newUser.getUsername());
            user.setPassword(newUser.getPassword());
            user.setEmail(newUser.getEmail());
            return userService.save(user);
        }).orElseGet(()-> userService.save(newUser));
    }

    @DeleteMapping(value="/users/{id}")
            public void delete(@PathVariable Long id){
        userService.deleteById(id);
    }

     */


}
