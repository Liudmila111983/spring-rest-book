drop table if exists type_of_incident;
drop table if exists incident_reports;
drop table if exists status;


CREATE TABLE type_of_incident (
type_id int NOT NULL,
description varchar(20) NOT NULL,
PRIMARY KEY (type_id)
);

CREATE TABLE incident_reports (
incident_id int NOT NULL,
date date not null,
type_id int,
foreign key (type_id) references type_of_incident,
PRIMARY KEY (incident_id)
);

CREATE TABLE status (
status_id int not null,
status_name text not null,
PRIMARY KEY (status_id)
);




