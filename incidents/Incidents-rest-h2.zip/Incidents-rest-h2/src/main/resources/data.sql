insert into type_of_incident(type_id, description)
values(1, 'кража'), (2, 'убийство'), (3, 'взятка'), (4, 'разбой'), (5, 'изнасилование');
